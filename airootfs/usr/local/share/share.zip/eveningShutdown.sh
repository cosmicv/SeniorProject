#!/bin/bash
shutdown -r +5
zenity --info --text="System is going down at in 5 minutes"