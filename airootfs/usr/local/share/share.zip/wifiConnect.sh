#!/bin/sh
#connect to guest network wifi

nmcli dev wifi connect Guest password